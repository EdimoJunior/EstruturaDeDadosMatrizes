package iftm;

import java.util.Scanner;

/**
 * 
 * @author edimo
 *	OBS: se vc testar no menu op��es inv�lidas com inteiros diferente das op��es v�lidas funciona, m�s se testar com
 *	alguma coisa que n�o seja inteiro funciona no menu m�s depois da erro. Ex: se testar inserir op��o = cachorro d� erro!
 */

public class Matrizes {

	public static void main(String[] args) {

		menu();

	}

	public static void menu() {

		int opc = 0;
		Scanner sc = new Scanner(System.in);

		System.out.println("Escolha uma op��o v�lida: ");
		System.out.println("1 -> Pegar diagonal principal e secundaria de uma matriz.");
		System.out.println("2 -> Pegar triangulo superior e inferior de uma matriz.");
		System.out.println("3 -> Multiplicar duas matrizes.");
		System.out.print("op��o: ");
		try {
			opc = sc.nextInt();
		} catch (Exception e) {
			System.out.println("\nVoc� informou uma op��o n�o v�lida.\n");
			sc.nextLine();
			menu();
		}

		switch (opc) {
		case 1:
			pegarDiagonais();
			break;

		case 2:
			pegarTriangulos();
			break;

		case 3:
			multiplicarMatrizes();
			break;

		default:
			System.out.println("\nVoc� informou uma op��o n�o v�lida.\n");
			opc = 0;
			menu();
			break;
		}
		sc.close();

	}

	public static void pegarDiagonais() {
		Scanner sc1 = new Scanner(System.in);
		int n;

		System.out.println("\nEntre com a ordem da matriz que deseja obter as diagonais: ");
		System.out.print("Ordem: ");
		try {
			n = sc1.nextInt();
			if (n <= 0) {
				System.out.println("\nVoc� informou um valor inv�lido p/ o campo ORDEM.\n");
				n = 0;
				pegarDiagonais();
			}
		} catch (Exception e) {
			System.out.println("\nVoc� informou um valor inv�lido p/ o campo ORDEM.\n");
			n = 0;
			pegarDiagonais();
		}

		Object[][] matriz = new Object[n][n];

		for (int i = 0; i < matriz.length; i++) {
			for (int j = 0; j < matriz.length; j++) {
				System.out.print("Matriz[" + (i + 1) + "][" + (j + 1) + "]: ");
				matriz[i][j] = sc1.next();
			}
		}
		System.out.println("\nSua matriz: ");
		for (int i = 0; i < matriz.length; i++) {
			for (int j = 0; j < matriz.length; j++) {
				System.out.print(matriz[i][j] + "\t");
			}
			System.out.println();
		}

		System.out.print("\nElementos da diagonal principal: ");
		for (int i = 0; i < matriz.length; i++) {
			for (int j = 0; j < matriz.length; j++) {
				if (i == j) {
					System.out.print(matriz[i][j] + ", ");
				}
			}
		}
		System.out.print("\nElementos da diagonal principal: ");
		int col = matriz.length - 1;
		for (int row = 0; row < matriz.length; row++) {
			System.out.print(matriz[row][col] + ", ");
			col--;
		}
		sc1.close();
	}

	public static void pegarTriangulos() {

		Scanner sc2 = new Scanner(System.in);
		int n;

		System.out.println("\nEntre com a ordem da matriz que deseja obter os tri�ngulos: ");
		System.out.print("Ordem: ");
		try {
			n = sc2.nextInt();
			if (n <= 0) {
				System.out.println("\nVoc� informou um valor inv�lido p/ o campo ORDEM.\n");
				n = 0;
				pegarDiagonais();
			}
		} catch (Exception e) {
			System.out.println("\nVoc� informou um valor inv�lido p/ o campo ORDEM.\n");
			n = 0;
			pegarDiagonais();
		}

		Object[][] matriz = new Object[n][n];

		for (int i = 0; i < matriz.length; i++) {
			for (int j = 0; j < matriz.length; j++) {
				System.out.print("Matriz[" + (i + 1) + "][" + (j + 1) + "]: ");
				matriz[i][j] = sc2.next();
			}
		}
		System.out.println("\nSua matriz: ");
		for (int i = 0; i < matriz.length; i++) {
			for (int j = 0; j < matriz.length; j++) {
				System.out.print(matriz[i][j] + "\t");
			}
			System.out.println();
		}
		
		System.out.println("\nElementos do tri�ngulo superior: ");
		for (int i = 0; i < matriz.length; i++) {
			for (int j = 0; j < matriz.length; j++) {
				if (i < j) {
					System.out.println("Matriz[" + (i + 1) + "][" + (j + 1) + "]: " + matriz[i][j]);
				}
			}
		}
		System.out.println("\nElementos do tri�ngulo inferior: ");
		for (int i = 0; i < matriz.length; i++) {
			for (int j = 0; j < matriz.length; j++) {
				if (i > j) {
					System.out.println("Matriz[" + (i + 1) + "][" + (j + 1) + "]: " + matriz[i][j]);
				}
			}
		}
		
		sc2.close();
	}

	public static void multiplicarMatrizes() {

		Scanner sc3 = new Scanner(System.in);
		int[] ordemA = new int[2];
		System.out.println("Digite a ordem da primeira matriz (m n): ");
		ordemA[0] = sc3.nextInt();
		ordemA[1] = sc3.nextInt();
		while (ordemA[0] <= 0 || ordemA[1] <= 0) {
			System.out.println("O numero de linhas n�o pode ser menor ou igual a 0\nDigite novamente: ");
			ordemA[0] = sc3.nextInt();
			ordemA[1] = sc3.nextInt();
		}

		int[] ordemB = new int[2];
		System.out.println("Digite a ordem da segunda matriz (m n): ");
		ordemB[0] = sc3.nextInt();
		ordemB[1] = sc3.nextInt();
		while (ordemB[0] <= 0 || ordemB[1] <= 0) {
			System.out.println("O numero de linhas n�o pode ser menor ou igual a 0\nDigite novamente:");
			ordemB[0] = sc3.nextInt();
			ordemB[1] = sc3.nextInt();
		}

		if (ordemA[1] != ordemB[0]) {
			System.out.println("Imposs�vel multiplicar as matrizes pois o numero de colunas da primeira matriz"
					+ " tem que ser igual ao numero de linhas da segunda matriz mx(n) = (m)xn\n\n");
		} else {
			System.out.println("\nDigite a 1� matriz: ");
			int[][] matrizA = new int[ordemA[0]][ordemA[1]];
			for (int i = 0; i < ordemA[0]; i++) {
				for (int j = 0; j < ordemA[1]; j++) {
					System.out.print("A[" + (i + 1) + "][" + (j + 1) + "]: ");
					matrizA[i][j] = sc3.nextInt();
				}
			}
			
			System.out.println("\n1� matriz: ");
			for (int i = 0; i < ordemA[0]; i++) {
				for (int j = 0; j < ordemA[1]; j++) {
					System.out.print(matrizA[i][j] + "\t");
				}
				System.out.println();
			}

			System.out.println("\nDigite a 2� matriz: ");
			int[][] matrizB = new int[ordemB[0]][ordemB[1]];
			for (int i = 0; i < ordemB[0]; i++) {
				for (int j = 0; j < ordemB[1]; j++) {
					System.out.print("B[" + (i + 1) + "][" + (j + 1) + "]: ");
					matrizB[i][j] = sc3.nextInt();
				}
			}
			
			System.out.println("\n2� matriz: ");
			for (int i = 0; i < ordemB[0]; i++) {
				for (int j = 0; j < ordemB[1]; j++) {
					System.out.print(matrizB[i][j] + "\t");
				}
				System.out.println();
			}

			int matrizC[][] = new int[ordemA[0]][ordemB[1]];
			for (int i = 0; i < matrizA.length; i++) {
				for (int j = 0; j < matrizB[0].length; j++) {
					for (int k = 0; k < matrizA[0].length; k++) {
						matrizC[i][j] += (matrizA[i][k] * matrizB[k][j]);
					}
				}
			}
			System.out.println("\nResultado da multiplica��o das matrizes: ");
			for (int i = 0; i < ordemA[0]; i++) {
				for (int j = 0; j < ordemB[1]; j++) {
					System.out.print(matrizC[i][j] + "\t");
				}
				System.out.println();
			}
		}
		sc3.close();
	}

}